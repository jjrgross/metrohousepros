# Upload TurnedKey Files to Your Repo

## 🎯 Goal: Completely Separate from Metro House Pros

Your **turnedkey** repo at https://github.com/jjrgross/turnedkey will be:
- ✅ Separate repository
- ✅ Separate Cloudflare Pages project
- ✅ Separate domain (turnedkey.com)
- ✅ Separate lead storage
- ✅ Separate deployments

**ZERO connection to Metro House Pros!**

---

## 📤 Option 1: Upload via GitHub Web (Easiest)

1. **Download this folder** to your computer
2. Go to: https://github.com/jjrgross/turnedkey
3. Click **"Add file"** → **"Upload files"**
4. Drag ALL these files:
   - `dist/` folder
   - `functions/` folder
   - `.github/` folder
   - `README.md`
5. Commit message: "Initial TurnedKey website"
6. Click **"Commit changes"**

---

## 📤 Option 2: Git Command Line

If you have git access on your local machine:

```bash
# Download/copy this folder to your computer
cd /path/to/turnedkey-export

# Initialize git
git init
git add .
git commit -m "Initial TurnedKey website"

# Connect to your repo
git remote add origin https://github.com/jjrgross/turnedkey.git

# Push
git push -u origin main
```

---

## 🚀 After Uploading

### Deploy to Cloudflare Pages:

1. **Go to:** https://dash.cloudflare.com/
2. **Workers & Pages** → **Create** → **Pages**
3. **Connect to Git**
4. **Select:** jjrgross/turnedkey (NOT metrohousepros!)
5. **Configure:**
   ```
   Project name: turnedkey
   Production branch: main
   Build output directory: dist
   ```
6. **Deploy!**

### Add Environment Variables:
1. Project Settings → Environment variables
2. Add: `RESEND_API_KEY` (from https://resend.com/api-keys)

### Create KV Namespace:
1. Workers & Pages → KV → Create namespace
2. Name: `turnedkey-leads`
3. Bind to project as `LEADS_KV`

### Add Custom Domain:
1. Custom domains → Add: `turnedkey.com`
2. Add: `www.turnedkey.com`

---

## ✅ Result

**Completely separate systems:**

### Metro House Pros:
- Repo: metrohousepros
- Domain: metrohousepros.com
- Cloudflare Project: metro-house-pros
- Leads: Stored separately

### TurnedKey Properties:
- Repo: turnedkey ← **This one!**
- Domain: turnedkey.com
- Cloudflare Project: turnedkey
- Leads: Stored separately

**No overlap, no shared code!**

---

## 📞 Questions?

Let me know when you've uploaded the files!
